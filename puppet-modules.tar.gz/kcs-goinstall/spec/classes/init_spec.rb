require 'spec_helper'
describe 'goinstall' do

  context 'with defaults for all parameters' do
    it { should contain_class('goinstall') }
  end
end
