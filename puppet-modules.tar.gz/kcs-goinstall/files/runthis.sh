#!/bin/sh

choos=$1

if [ $choos = start ]; then
/bin/go run /opt/go/test.go &
fi

if [ $choos = stop ]; then
ps axms | grep go | grep -v "grep" | awk {'print $2'} >> ./pids
for i in `cat ./pids`
    do
	kill -9 $i
done
rm ./pids
fi


